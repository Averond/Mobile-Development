export function makePost(post) {
    let postList = document.querySelector("#postList");

    let rootElement = document.createElement("article");
    rootElement.classList.add("post");

    rootElement.innerHTML = `
        <div class="post-top">
            <img class="sub-icon" src="https://picsum.photos/id/10/50/50" alt="">
            <span class="sub-name">${post.subreddit}</span>
            <span class="time">· ${post.time}</span>
            <button class="join">Join</button>
        </div>

        <div class="post-body">
            <div class="post-text">
                <h2>${post.title}</h2>
                <a href="#">${post.link}</a>
            </div>
            <img class="thumb" src="${post.imgUrl}" alt="">
        </div>

        <div class="post-buttons">
            <button class="pill">⬆ ${post.upvotes} ⬇</button>
            <button class="pill">💬 ${post.comments}</button>
            <button class="pill">🏅 ${post.awards}</button>
            <button class="pill">➦ Share</button>
        </div>
    `;

    postList.appendChild(rootElement);
}